import React, { useState, useEffect, useRef } from 'react'
import './App.css'

function App() {
  // Load positions from localStorage or use defaults
  const getInitialPositions = () => {
    const saved = localStorage.getItem('circlePositions')
    if (saved) {
      try {
        return JSON.parse(saved)
      } catch (e) {
        console.error('Failed to parse saved positions:', e)
      }
    }
    // Default positions
    return {
      1: { top: 61.13550815558344, right: 51.79086538461538 },
      2: { top: 54.50321518193224, right: 56.02564102564103 },
      3: { top: 47.43961731493099, right: 57.05128205128205 },
      4: { top: 48.674717691342536, right: 43.333333333333336 },
      5: { top: 56.3107747804266, right: 36.45833333333333 }
    }
  }

  const [overlayPositions, setOverlayPositions] = useState(getInitialPositions)

  const [currentCircle, setCurrentCircle] = useState(1)
  const [step, setStep] = useState('idle') // idle, sealing, starting, massaging, releasing, autoStarting
  const [timeRemaining, setTimeRemaining] = useState(10)
  const [timeRemainingPrecise, setTimeRemainingPrecise] = useState(10)
  const [autoStartCountdown, setAutoStartCountdown] = useState(5)
  const [isPaused, setIsPaused] = useState(false)
  const [sealingProgress, setSealingProgress] = useState(0)
  const [releasingProgress, setReleasingProgress] = useState(0)
  const [showMassageInProgress, setShowMassageInProgress] = useState(false)
  const [showReleasingShortly, setShowReleasingShortly] = useState(false)
  
  const timerRef = useRef(null)
  const sealingTimerRef = useRef(null)
  const releasingTimerRef = useRef(null)
  const autoStartTimerRef = useRef(null)
  const massagingStartTimeRef = useRef(null)
  const pausedDurationRef = useRef(0)

  const [dragging, setDragging] = useState(null)
  const [dragOffset, setDragOffset] = useState({ x: 0, y: 0 })

  // Sealing animation (5 seconds)
  useEffect(() => {
    if (step === 'sealing') {
      setSealingProgress(0)
      const duration = 5000 // 5 seconds
      const interval = 50 // Update every 50ms
      let progress = 0
      
      sealingTimerRef.current = setInterval(() => {
        progress += interval
        setSealingProgress((progress / duration) * 100)
        
        if (progress >= duration) {
          clearInterval(sealingTimerRef.current)
          setStep('starting')
          // Start countdown immediately
          setTimeRemaining(10)
          setTimeRemainingPrecise(10)
          setIsPaused(false)
          massagingStartTimeRef.current = null
          pausedDurationRef.current = 0
          setShowMassageInProgress(false)
          setShowReleasingShortly(false)
          
          // After 2 seconds, change to "Hybrid Massage in progress"
          setTimeout(() => {
            setShowMassageInProgress(true)
            setStep('massaging')
          }, 2000)
        }
      }, interval)
      
      return () => {
        if (sealingTimerRef.current) {
          clearInterval(sealingTimerRef.current)
        }
      }
    }
  }, [step])

  // Countdown timer - smooth animation (starts during "starting" step)
  useEffect(() => {
    if ((step === 'starting' || step === 'massaging') && !isPaused) {
      // Initialize start time if not set
      if (!massagingStartTimeRef.current) {
        massagingStartTimeRef.current = Date.now() - pausedDurationRef.current
      }
      
      const updateTimer = () => {
        const now = Date.now()
        const elapsed = now - massagingStartTimeRef.current
        const remaining = Math.max(0, (10 * 1000) - elapsed)
        const remainingSeconds = remaining / 1000
        
        setTimeRemainingPrecise(remainingSeconds)
        setTimeRemaining(Math.ceil(remainingSeconds))
        
        // Show "releasing shortly" text when 2 seconds remain (just text change, no step change)
        if (remainingSeconds <= 2 && remainingSeconds > 1.5) {
          setShowReleasingShortly(true)
        }
        
        if (remaining <= 0) {
          clearInterval(timerRef.current)
          setTimeRemainingPrecise(0)
          setTimeRemaining(0)
          massagingStartTimeRef.current = null
          pausedDurationRef.current = 0
          // Now transition to releasing step
          setStep('releasing')
        }
      }
      
      timerRef.current = setInterval(updateTimer, 50) // Update every 50ms for smooth animation
      
      return () => {
        if (timerRef.current) {
          clearInterval(timerRef.current)
        }
      }
    } else if (step === 'massaging' && isPaused) {
      // Track how long we've been paused
      if (massagingStartTimeRef.current) {
        pausedDurationRef.current = Date.now() - massagingStartTimeRef.current
      }
      // Clear timer when paused
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    } else if (step !== 'starting' && step !== 'massaging') {
      // Reset when leaving massaging step
      massagingStartTimeRef.current = null
      pausedDurationRef.current = 0
      setShowReleasingShortly(false)
      if (timerRef.current) {
        clearInterval(timerRef.current)
      }
    }
  }, [step, isPaused])

  // Releasing animation (3 seconds)
  useEffect(() => {
    if (step === 'releasing') {
      setReleasingProgress(0)
      const duration = 3000 // 3 seconds
      const interval = 50 // Update every 50ms
      let progress = 0
      
      releasingTimerRef.current = setInterval(() => {
        progress += interval
        setReleasingProgress((progress / duration) * 100)
        
        if (progress >= duration) {
          clearInterval(releasingTimerRef.current)
          // Auto-advance to next circle after releasing
          if (currentCircle < 5) {
            // Smoothly transition to next circle with animation
            setTimeout(() => {
              setCurrentCircle(prev => prev + 1)
              setStep('autoStarting')
              setAutoStartCountdown(5)
            }, 100) // Small delay to allow circle transition animation
          } else {
            // Exercise complete
            setStep('complete')
          }
        }
      }, interval)
      
      return () => {
        if (releasingTimerRef.current) {
          clearInterval(releasingTimerRef.current)
        }
      }
    }
  }, [step, currentCircle])

  // Auto-starting countdown (5 seconds)
  useEffect(() => {
    if (step === 'autoStarting') {
      autoStartTimerRef.current = setInterval(() => {
        setAutoStartCountdown(prev => {
          if (prev <= 1) {
            clearInterval(autoStartTimerRef.current)
            // Automatically start sealing
            setStep('sealing')
            setSealingProgress(0)
            setTimeRemaining(10)
            setTimeRemainingPrecise(10)
            setIsPaused(false)
            return 0
          }
          return prev - 1
        })
      }, 1000)
      
      return () => {
        if (autoStartTimerRef.current) {
          clearInterval(autoStartTimerRef.current)
        }
      }
    }
  }, [step])

  const handleStart = () => {
    if (step === 'idle') {
      setStep('sealing')
    } else if (step === 'massaging') {
      if (isPaused) {
        // Resume from current time
        setIsPaused(false)
      } else {
        // Pause
        setIsPaused(true)
      }
    }
  }

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${String(mins).padStart(2, '0')}:${String(secs).padStart(2, '0')}`
  }

  const getInstructionText = () => {
    switch (step) {
      case 'idle':
        return (
          <>
            Place applicator on{' '}
            <span className="instruction-circle"></span>
            <br />
            and press Start
          </>
        )
      case 'sealing':
        return 'Applicator sealing'
      case 'starting':
        return 'Starting Hybrid Massage'
      case 'massaging':
        if (showReleasingShortly) {
          return 'Applicator releasing shortly...'
        }
        return showMassageInProgress ? 'Hybrid Massage in progress' : 'Starting Hybrid Massage'
      case 'releasing':
        return 'Applicator releasing'
      case 'autoStarting':
        return (
          <>
            Place applicator on{' '}
            <span className="instruction-circle"></span>
            <br />
            <span className="auto-starting-text">Auto starting</span>
          </>
        )
      case 'complete':
        return 'Exercise complete!'
      default:
        return ''
    }
  }

  const getButtonText = () => {
    if (step === 'idle') {
      return 'Start'
    } else if (step === 'sealing') {
      return 'Sealing...'
    } else if (step === 'starting' || step === 'massaging') {
      // This won't be used for massaging anymore, but keep for starting
      return formatTime(timeRemaining)
    } else if (step === 'releasing') {
      return formatTime(timeRemaining)
    } else if (step === 'autoStarting') {
      return formatTime(autoStartCountdown)
    } else {
      return 'Start'
    }
  }

  const handleMouseDown = (e, overlayNum) => {
    e.preventDefault()
    const rect = e.currentTarget.getBoundingClientRect()
    const containerRect = e.currentTarget.parentElement.getBoundingClientRect()
    
    setDragging(overlayNum)
    setDragOffset({
      x: e.clientX - rect.left - rect.width / 2,
      y: e.clientY - rect.top - rect.height / 2
    })
  }

  const handleMouseMove = (e) => {
    if (!dragging) return
    
    const container = document.querySelector('.image-container')
    if (!container) return
    
    const containerRect = container.getBoundingClientRect()
    const x = e.clientX - containerRect.left - dragOffset.x
    const y = e.clientY - containerRect.top - dragOffset.y
    
    const rightPercent = ((containerRect.width - x) / containerRect.width) * 100
    const topPercent = (y / containerRect.height) * 100

    setOverlayPositions(prev => {
      const newPositions = {
        ...prev,
        [dragging]: {
          top: Math.max(0, Math.min(100, topPercent)),
          right: Math.max(0, Math.min(100, rightPercent))
        }
      }
      // Save to localStorage immediately
      localStorage.setItem('circlePositions', JSON.stringify(newPositions))
      return newPositions
    })
  }

  const handleMouseUp = () => {
    if (dragging) {
      // Log current positions for saving
      console.log('Current circle positions:')
      console.log(JSON.stringify(overlayPositions, null, 2))
    }
    setDragging(null)
  }

  React.useEffect(() => {
    if (dragging) {
      document.addEventListener('mousemove', handleMouseMove)
      document.addEventListener('mouseup', handleMouseUp)
      return () => {
        document.removeEventListener('mousemove', handleMouseMove)
        document.removeEventListener('mouseup', handleMouseUp)
      }
    }
  }, [dragging, dragOffset])


  return (
    <div className="app-wrapper">
      <div className="phone-container">
      {/* Status Bar */}
      <div className="status-bar">
        <img 
          src="/Dynamic Island.png" 
          alt="iPhone status bar with Dynamic Island"
          className="status-bar-image"
        />
      </div>

      {/* Main Content */}
      <div className="app-content">
        {/* Header */}
        <div className="header">
          <h1 className="routine-title">Shoulder Warmup Routine</h1>
          <p className="step-indicator">Step {currentCircle} of 5</p>
        </div>

        {/* Image Container with Overlays */}
        <div className="image-container">
          <img 
            src="/woman-image.png" 
            alt="Woman demonstrating shoulder warmup"
            className="main-image"
            onError={(e) => {
              e.target.style.display = 'none';
            }}
          />
          
          {/* Blur overlay at bottom */}
          <div className="image-blur-overlay"></div>
          
          {/* Numbered Overlays */}
          {[1, 2, 3, 4, 5].map(num => (
            <div 
              key={num}
              className={`overlay-circle overlay-${num} ${currentCircle === num ? `active ${step}${step === 'massaging' && isPaused ? ' paused' : ''}` : ''} ${dragging === num ? 'dragging' : ''}`}
              style={{
                top: `${overlayPositions[num].top}%`,
                right: `${overlayPositions[num].right}%`
              }}
              onMouseDown={(e) => handleMouseDown(e, num)}
            >{num}</div>
          ))}
        </div>

        {/* Instructions */}
        <div className="instructions">
          <p 
            key={step === 'massaging' ? 'massaging' : step}
            data-animate={step === 'massaging' && showMassageInProgress ? 'false' : 'true'}
          >
            {getInstructionText()}
          </p>
        </div>

        {/* Bottom Navigation */}
        <div className="bottom-nav">
          <button className="nav-button back-button">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
              <path d="M19 12H5M12 19l-7-7 7-7"/>
            </svg>
          </button>
          
          <button 
            className={`start-button ${step === 'sealing' ? 'sealing' : ''} ${(step === 'massaging' || step === 'starting') ? 'massaging' : ''} ${step === 'releasing' ? 'releasing' : ''}`}
            onClick={handleStart}
            disabled={step === 'starting' || step === 'releasing' || step === 'autoStarting' || step === 'complete'}
          >
            {(step === 'massaging' || step === 'starting') && (
              <div className="massage-progress" style={{ width: `${((10 - timeRemainingPrecise) / 10) * 100}%` }}></div>
            )}
            {step === 'releasing' && (
              <div className="releasing-progress" style={{ width: `${releasingProgress}%` }}></div>
            )}
            {step === 'sealing' ? (
              <span className="button-text button-dots">
                <span className="dot">.</span>
                <span className="dot">.</span>
                <span className="dot">.</span>
              </span>
            ) : (step === 'massaging' || step === 'starting') ? (
              isPaused ? (
                <span className="button-text">Resume</span>
              ) : (
                <>
                  <span className="button-text button-timer">{formatTime(timeRemaining)}</span>
                  <svg className="pause-icon" width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#ffffff" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round">
                    <line x1="8" y1="6" x2="8" y2="18"/>
                    <line x1="16" y1="6" x2="16" y2="18"/>
                  </svg>
                </>
              )
            ) : step === 'autoStarting' ? (
              <span className="button-text">{autoStartCountdown}</span>
            ) : (
              <span className="button-text">{getButtonText()}</span>
            )}
          </button>
          
          <button className="nav-button menu-button">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="currentColor">
              <circle cx="12" cy="6" r="1.5"/>
              <circle cx="12" cy="12" r="1.5"/>
              <circle cx="12" cy="18" r="1.5"/>
            </svg>
          </button>
        </div>

        {/* Home Indicator */}
        <div className="home-indicator"></div>
      </div>
      </div>
    </div>
  )
}

export default App
